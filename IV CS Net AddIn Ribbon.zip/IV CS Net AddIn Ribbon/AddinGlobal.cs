﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Inventor;

namespace $safeprojectname$
{

  // Namespace InventorNetAddinVB1
  public class AddinGlobal
  {
    public static Application IVApp;
    public static string RibbonPanelId;
    public static RibbonPanel RibbonPanel;
    public static List<InventorButton> ButtonList = new();
    private static string mClassId;

    public static string ClassId
    {
      get
      {
        if (!string.IsNullOrEmpty(mClassId))
        {
          return mClassId;
        }
        else
        {
          throw new Exception("The addin server class id hasn't been gotten yet!");
        }
      }
      set
      {
        mClassId = value;
      }
    }

    public static void GetAddinClassId(Type t)
    {
      GuidAttribute guidAtt = (GuidAttribute)System.Attribute.GetCustomAttribute(t, typeof(GuidAttribute));
      mClassId = "{" + guidAtt.Value + "}";
    }
  }
}
// End Namespace


