﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Inventor;

namespace $safeprojectname$
{

  // Namespace InventorNetAddinVB1
  /// <summary>
/// The class wrapps up Inventor Button creation stuffs and is easy to use.
/// No need to derive. Create an instance using either constructor and assign the Action.
/// </summary>
  public class InventorButton
  {
    #region Fields & Properties

    private ButtonDefinition mButtonDef;
    public ButtonDefinition ButtonDef
    {
      get
      {
        return mButtonDef;
      }
      set
      {
        mButtonDef = value;
      }
    }

    #endregion

    #region Constructors

    /// <summary>
  /// The most comprehensive signature.
  /// </summary>
    public InventorButton(string displayName, string internalName, string description, string tooltip, Icon standardIcon, Icon largeIcon, CommandTypesEnum commandType, ButtonDisplayEnum buttonDisplayType)
    {
      Create(displayName, internalName, description, tooltip, AddinGlobal.ClassId, standardIcon, largeIcon, commandType, buttonDisplayType);
    }

    /// <summary>
  /// The signature does not care about Command Type (always editing) and Button Display (always with text).
  /// </summary>
    public InventorButton(string displayName, string internalName, string description, string tooltip, Icon standardIcon, Icon largeIcon)
    {
      Create(displayName, internalName, description, tooltip, AddinGlobal.ClassId, null, null, CommandTypesEnum.kEditMaskCmdType, ButtonDisplayEnum.kAlwaysDisplayText);
    }

    /// <summary>
  /// The signature does not care about icons.
  /// </summary>
    public InventorButton(string displayName, string internalName, string description, string tooltip, CommandTypesEnum commandType, ButtonDisplayEnum buttonDisplayType)
    {
      Create(displayName, internalName, description, tooltip, AddinGlobal.ClassId, null, null, commandType, buttonDisplayType);
    }

    /// <summary>
  /// This signature only cares about display name and icons.
  /// </summary>
  /// <param name="displayName"></param>
  /// <param name="standardIcon"></param>
  /// <param name="largeIcon"></param>
    public InventorButton(string displayName, Icon standardIcon, Icon largeIcon)
    {
      Create(displayName, displayName, displayName, displayName, AddinGlobal.ClassId, standardIcon, largeIcon, CommandTypesEnum.kEditMaskCmdType, ButtonDisplayEnum.kAlwaysDisplayText);
    }

    /// <summary>
  /// The simplest signature, which can be good for prototyping.
  /// </summary>
    public InventorButton(string displayName)
    {
      Create(displayName, displayName, displayName, displayName, AddinGlobal.ClassId, null, null, CommandTypesEnum.kEditMaskCmdType, ButtonDisplayEnum.kAlwaysDisplayText);
    }

    /// <summary>
  /// The helper method for constructors to call to avoid duplicate code.
  /// </summary>
    public void Create(string displayName, string internalName, string description, string tooltip, string clientId, Icon standardIcon, Icon largeIcon, CommandTypesEnum commandType, ButtonDisplayEnum buttonDisplayType)
    {
      if (string.IsNullOrEmpty(clientId))
      {
        clientId = AddinGlobal.ClassId;
      }

      stdole.IPictureDisp standardIconIPictureDisp = null;
      stdole.IPictureDisp largeIconIPictureDisp = null;
      if (standardIcon is not null)
      {
        standardIconIPictureDisp = IconToPicture(standardIcon);
        largeIconIPictureDisp = IconToPicture(largeIcon);
      }

      mButtonDef = AddinGlobal.IVApp.CommandManager.ControlDefinitions.AddButtonDefinition(displayName, internalName, commandType, clientId, description, tooltip, standardIconIPictureDisp, largeIconIPictureDisp, buttonDisplayType);

      mButtonDef.Enabled = true;
      mButtonDef.OnExecute += ButtonDefinition_OnExecute;

      DisplayText = true;

      AddinGlobal.ButtonList.Add(this);
    }

    #endregion

    #region Behavior

    public bool DisplayBigIcon
    {
      get
      {
        return m_DisplayBigIcon;
      }
      set
      {
        m_DisplayBigIcon = value;
      }
    }
    private bool m_DisplayBigIcon;

    public bool DisplayText
    {
      get
      {
        return m_DisplayText;
      }
      set
      {
        m_DisplayText = value;
      }
    }
    private bool m_DisplayText;

    public bool InsertBeforeTarget
    {
      get
      {
        return m_InsertBeforeTarget;
      }
      set
      {
        m_InsertBeforeTarget = value;
      }
    }
    private bool m_InsertBeforeTarget;

    public void SetBehavior(bool displayBigIcon__1, bool displayText__2, bool insertBeforeTarget__3)
    {
      DisplayBigIcon = displayBigIcon__1;
      DisplayText = displayText__2;
      InsertBeforeTarget = insertBeforeTarget__3;
    }

    public void CopyBehaviorFrom(InventorButton button)
    {
      DisplayBigIcon = button.DisplayBigIcon;
      DisplayText = button.DisplayText;
      InsertBeforeTarget = InsertBeforeTarget;
    }

    #endregion

    #region Actions

    /// <summary>
  /// The button callback method.
  /// </summary>
  /// <param name="context"></param>
    private void ButtonDefinition_OnExecute(NameValueMap context)
    {
      if (Execute is not null)
      {
        Execute();
      }
      else
      {
        MessageBox.Show("Nothing to execute.");
      }
    }

    /// <summary>
  /// The button action to be assigned from anywhere outside.
  /// </summary>
    public Action Execute;

    #endregion

    #region Image Converters

    public static stdole.IPictureDisp ImageToPicture(Image image)
    {
      return ImageConverter.ImageToPicture(image);
    }

    public static stdole.IPictureDisp IconToPicture(Icon icon)
    {
      return ImageConverter.ImageToPicture(icon.ToBitmap());
    }

    public static Image PictureToImage(stdole.IPictureDisp picture)
    {
      return ImageConverter.PictureToImage(picture);
    }

    public static Icon PictureToIcon(stdole.IPictureDisp picture)
    {
      return ImageConverter.PictureToIcon(picture);
    }

    private class ImageConverter : AxHost
    {
      public ImageConverter() : base(string.Empty)
      {
      }

      public static stdole.IPictureDisp ImageToPicture(Image image)
      {
        return (stdole.IPictureDisp)GetIPictureDispFromPicture(image);
      }

      public static stdole.IPictureDisp IconToPicture(Icon icon)
      {
        return ImageToPicture(icon.ToBitmap());
      }

      public static Image PictureToImage(stdole.IPictureDisp picture)
      {
        return GetPictureFromIPicture(picture);
      }

      public static Icon PictureToIcon(stdole.IPictureDisp picture)
      {
        var bitmap = new Bitmap(PictureToImage(picture));
        return Icon.FromHandle(bitmap.GetHicon());
      }
    }

    #endregion

  }
}
// End Namespace


