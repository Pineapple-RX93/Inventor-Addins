﻿using System;
// Imports Microsoft.Win32
using System.Drawing;
using System.Reflection;
using System.Runtime.InteropServices;
using Inventor;

namespace $safeprojectname$
{
  [Guid("$guid1$")]
  public class $safeprojectname$ : ApplicationAddInServer
  {
    // Public Sub New()
    // End Sub

    #region Data
    #endregion

    #region ApplicationAddInServer Members

    public void Activate(ApplicationAddInSite addInSiteObject, bool firstTime)
    {

      // This method is called by Inventor when it loads the AddIn.
      // The AddInSiteObject provides access to the Inventor Application object.
      // The FirstTime flag indicates if the AddIn is loaded for the first time.
      // Initialize AddIn members.
      AddinGlobal.IVApp = addInSiteObject.Application;

      try
      {
        AddinGlobal.GetAddinClassId(GetType());
        if (firstTime == true)
        {
          RibbonSetup();
        }
      }
      catch (Exception ex)
      {
        System.Windows.Forms.MessageBox.Show(ex.ToString());
      }

    }

    private void RibbonSetup()
    {
      // Set a reference to the user interface manager.
      Ribbon oRibbon;
      RibbonTab oTab;
      var oUIManager = AddinGlobal.IVApp.UserInterfaceManager;
      var Icon1 = new Icon(Assembly.GetExecutingAssembly().GetManifestResourceStream("addin.ico"));
      var Button1 = new InventorButton("Button 1", "InventorAddinServer.Button_" + Guid.NewGuid().ToString(), "Button 1 description", "Button 1 tooltip", Icon1, Icon1, CommandTypesEnum.kShapeEditCmdType, ButtonDisplayEnum.kDisplayTextInLearningMode);
      CommandControls cmdCtrls;

      Button1.SetBehavior(true, true, true);
      Button1.Execute = Button1_Execute;

      // Get the ribbon associated with documents
      // oRibbon = oUIManager.Ribbons.Item("Part")
      // oRibbon = oUIManager.Ribbons.Item("Assembly")
      oRibbon = oUIManager.Ribbons["Drawing"];

      // Create a new tab
      oTab = oRibbon.RibbonTabs["id_TabPlaceViews"];

      // Create a new panel within the tab
      AddinGlobal.RibbonPanelId = "{574f6ea7-aacb-4ef6-8979-c5523284e3ee}";
      AddinGlobal.RibbonPanel = oTab.RibbonPanels.Add("idw Export", "id_PanelA_BWM", AddinGlobal.RibbonPanelId);

      // Create a control within the panel
      cmdCtrls = AddinGlobal.RibbonPanel.CommandControls;
      cmdCtrls.AddButton(Button1.ButtonDef, Button1.DisplayBigIcon, Button1.DisplayText, "", Button1.InsertBeforeTarget);
    }

    public void Deactivate()
    {

      // This method is called by Inventor when the AddIn is unloaded.
      // The AddIn will be unloaded either manually by the user or
      // when the Inventor session is terminated.

      // TODO:  Add ApplicationAddInServer.Deactivate implementation
      foreach (InventorButton button in AddinGlobal.ButtonList)
      {
        if (button.ButtonDef is not null)
        {
          Marshal.FinalReleaseComObject(button.ButtonDef);
        }
      }
      if (AddinGlobal.RibbonPanel is not null)
      {
        Marshal.FinalReleaseComObject(AddinGlobal.RibbonPanel);
      }
      if (AddinGlobal.IVApp is not null)
      {
        Marshal.FinalReleaseComObject(AddinGlobal.IVApp);
      }

    }

    public object Automation
    {

      // This property is provided to allow the AddIn to expose an API 
      // of its own to other programs. Typically, this  would be done by
      // implementing the AddIn's API interface in a class and returning 
      // that class object through this property.

      get
      {
        return null;
      }

    }

    public void ExecuteCommand(int commandID)
    {
      // Note:this method is now obsolete, you should use the 
      // ControlDefinition functionality for implementing commands.

    }

    public void Button1_Execute()
    {
      try
      {
      }
      catch (Exception ex)
      {
        System.Windows.Forms.MessageBox.Show(ex.ToString());
      }
    }

    // Private Sub m_UserInterfaceEvents_OnResetRibbonInterface(Context As NameValueMap) Handles m_UserInterfaceEvents.OnResetRibbonInterface
    // RibbonSetup()
    // End Sub

    #endregion

  }
}